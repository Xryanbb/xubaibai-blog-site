(() => {
  const directoryToggle = document.querySelector(".directory-toggle");
  const mobileDirectory = document.querySelector("#mobile-directory");
  const grid = document.querySelector("#post-grid");
  const postControls = document.querySelector("#post-controls");
  const searchInput = document.querySelector("#post-search");
  const filterBar = document.querySelector("#filters");
  const articleView = document.querySelector("#article-view");
  const feedback = document.querySelector("#feedback");
  const count = document.querySelector("#post-count");
  let posts = [];
  let selectedCategory = "全部";

  const closeDirectory = () => {
    if (!directoryToggle || !mobileDirectory) return;
    directoryToggle.setAttribute("aria-expanded", "false");
    directoryToggle.setAttribute("aria-label", "打开目录");
    mobileDirectory.hidden = true;
  };

  if (directoryToggle && mobileDirectory) {
    directoryToggle.addEventListener("click", () => {
      const isOpen = directoryToggle.getAttribute("aria-expanded") === "true";
      directoryToggle.setAttribute("aria-expanded", String(!isOpen));
      directoryToggle.setAttribute("aria-label", isOpen ? "打开目录" : "关闭目录");
      mobileDirectory.hidden = isOpen;
    });
    mobileDirectory.querySelectorAll("a").forEach((link) => link.addEventListener("click", closeDirectory));
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") closeDirectory();
    });
  }

  if (!grid || !postControls || !searchInput || !filterBar || !articleView || !feedback || !count) return;

  const make = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };

  const normalize = (value, index) => ({
    id: String(value.id || `post-${index + 1}`),
    title: String(value.title || "未命名文章"),
    category: String(value.category || ""),
    summary: String(value.summary || ""),
    content: String(value.content || ""),
    publishedAt: String(value.publishedAt || "")
  });

  const sortedPosts = () => [...posts].sort((a, b) => b.publishedAt.localeCompare(a.publishedAt));

  const dateLabel = (value) => {
    if (!value) return "";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "";
    return new Intl.DateTimeFormat("zh-CN", { year: "numeric", month: "short", day: "numeric" }).format(date);
  };

  const renderFilters = () => {
    const categories = [...new Set(posts.map((post) => post.category).filter(Boolean))];
    const categoryKey = JSON.stringify(categories);
    if (categories.length < 2) {
      filterBar.hidden = true;
      selectedCategory = "全部";
      if (filterBar.dataset.categories !== categoryKey) {
        filterBar.replaceChildren();
        filterBar.dataset.categories = categoryKey;
      }
      return;
    }

    filterBar.hidden = false;
    if (filterBar.dataset.categories !== categoryKey) {
      filterBar.replaceChildren();
      ["全部", ...categories].forEach((category) => {
        const button = make("button", "filter-button", category);
        button.type = "button";
        button.dataset.category = category;
        button.addEventListener("click", () => {
          selectedCategory = category;
          renderPosts();
        });
        filterBar.append(button);
      });
      filterBar.dataset.categories = categoryKey;
    }
    filterBar.querySelectorAll(".filter-button").forEach((button) => {
      button.setAttribute("aria-pressed", String(selectedCategory === button.dataset.category));
    });
  };

  const renderPosts = () => {
    renderFilters();
    grid.replaceChildren();
    postControls.hidden = posts.length === 0;
    const query = searchInput.value.trim().toLocaleLowerCase("zh-CN");
    const visiblePosts = sortedPosts().filter((post) => {
      const matchesCategory = selectedCategory === "全部" || post.category === selectedCategory;
      const searchable = `${post.title} ${post.category} ${post.summary} ${post.content}`.toLocaleLowerCase("zh-CN");
      return matchesCategory && (!query || searchable.includes(query));
    });
    count.textContent = posts.length
      ? `（${query || selectedCategory !== "全部" ? `${visiblePosts.length}/` : ""}${posts.length}）`
      : "";
    feedback.textContent = query ? `找到 ${visiblePosts.length} 篇文章` : "";

    if (!posts.length) {
      const empty = make("div", "empty-state");
      empty.append(
        make("h3", "", "这里还没有文章"),
        make("p", "", "有新文章时会显示在这里。")
      );
      grid.append(empty);
      return;
    }

    if (!visiblePosts.length) {
      const empty = make("div", "empty-result-state");
      empty.append(make("p", "", "没有找到相关文章。"));
      const clearFilters = make("button", "text-link clear-filters", "清除搜索条件");
      clearFilters.type = "button";
      clearFilters.addEventListener("click", () => {
        selectedCategory = "全部";
        searchInput.value = "";
        renderPosts();
        searchInput.focus();
      });
      empty.append(clearFilters);
      grid.append(empty);
      return;
    }

    visiblePosts.forEach((post) => {
      const card = make("article", "post-card");
      if (post.category) card.append(make("p", "post-category", post.category));

      const link = make("a", "post-open");
      link.href = `#article/${encodeURIComponent(post.id)}`;
      link.append(make("h3", "post-title", post.title));
      card.append(link);

      const summary = post.summary || post.content.split(/\n\s*\n/)[0] || "";
      if (summary) card.append(make("p", "post-summary", summary));
      const date = dateLabel(post.publishedAt);
      if (date) {
        const time = make("time", "post-date", date);
        time.dateTime = post.publishedAt;
        card.append(time);
      }

      const readMore = make("a", "text-link post-more", "阅读全文　↗");
      readMore.href = link.href;
      const actions = make("div", "card-actions");
      actions.append(readMore);
      card.append(actions);
      grid.append(card);
    });
  };

  const showArticle = () => {
    const match = location.hash.match(/^#article\/(.+)$/);
    if (!match) {
      articleView.hidden = true;
      articleView.replaceChildren();
      grid.hidden = false;
      postControls.hidden = posts.length === 0;
      return;
    }

    let id;
    try {
      id = decodeURIComponent(match[1]);
    } catch {
      location.hash = "#posts";
      return;
    }

    const post = posts.find((item) => item.id === id);
    articleView.hidden = false;
    grid.hidden = true;
    postControls.hidden = true;
    articleView.replaceChildren();

    if (!post) {
      articleView.append(make("p", "empty-result", "这篇文章不存在或已删除。"));
      return;
    }

    const back = make("a", "text-link article-back", "←　所有文章");
    back.href = "#posts";
    articleView.append(back);

    const article = make("article", "reading-page");
    if (post.category) article.append(make("p", "post-category", post.category));
    const title = make("h1", "reading-title", post.title);
    title.tabIndex = -1;
    article.append(title);

    const date = dateLabel(post.publishedAt);
    if (date) {
      const time = make("time", "post-date", date);
      time.dateTime = post.publishedAt;
      article.append(time);
    }

    const content = make("div", "reading-content");
    post.content.split(/\n\s*\n/).filter((paragraph) => paragraph.trim()).forEach((paragraph) => {
      content.append(make("p", "", paragraph.trim()));
    });
    article.append(content);
    articleView.append(article);
  };

  window.addEventListener("hashchange", showArticle);
  searchInput.addEventListener("input", renderPosts);

  fetch("./posts.json", { cache: "no-store" })
    .then((response) => {
      if (!response.ok) throw new Error("文章文件暂时无法读取。");
      return response.json();
    })
    .then((data) => {
      if (data.version !== 1 || !Array.isArray(data.posts)) throw new Error("文章文件格式不正确。");
      posts = data.posts.map(normalize);
      feedback.textContent = "";
      renderPosts();
      showArticle();
    })
    .catch(() => {
      posts = [];
      postControls.hidden = true;
      count.textContent = "";
      feedback.textContent = "";
      grid.replaceChildren();
      const failure = make("div", "empty-state load-error");
      failure.append(
        make("h3", "", "文章暂时无法读取"),
        make("p", "", "检查网络后刷新页面试试。")
      );
      grid.append(failure);
    });
})();
