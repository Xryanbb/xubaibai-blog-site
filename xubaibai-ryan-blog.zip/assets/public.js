(() => {
  const directoryToggle = document.querySelector(".directory-toggle");
  const mobileDirectory = document.querySelector("#mobile-directory");
  const latestList = document.querySelector("#latest-post-list");
  const grid = document.querySelector("#post-grid");
  const postControls = document.querySelector("#post-controls");
  const searchInput = document.querySelector("#post-search");
  const filterBar = document.querySelector("#filters");
  const articleView = document.querySelector("#article-view");
  const feedback = document.querySelector("#feedback");
  const isEnglish = document.documentElement.lang.toLowerCase().startsWith("en");
  const allCategory = isEnglish ? "All" : "全部";
  let posts = [];
  let selectedCategory = allCategory;

  const closeDirectory = () => {
    if (!directoryToggle || !mobileDirectory) return;
    directoryToggle.setAttribute("aria-expanded", "false");
    directoryToggle.setAttribute("aria-label", isEnglish ? "Open menu" : "打开目录");
    mobileDirectory.hidden = true;
  };

  if (directoryToggle && mobileDirectory) {
    directoryToggle.addEventListener("click", () => {
      const isOpen = directoryToggle.getAttribute("aria-expanded") === "true";
      directoryToggle.setAttribute("aria-expanded", String(!isOpen));
      directoryToggle.setAttribute("aria-label", isEnglish
        ? (isOpen ? "Open menu" : "Close menu")
        : (isOpen ? "打开目录" : "关闭目录"));
      mobileDirectory.hidden = isOpen;
    });
    mobileDirectory.querySelectorAll("a").forEach((link) => link.addEventListener("click", closeDirectory));
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") closeDirectory();
    });
  }

  const make = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };

  const normalize = (value, index) => ({
    id: String(value.id || `post-${index + 1}`),
    title: String(value.title || (isEnglish ? "Untitled" : "未命名文章")),
    category: String(value.category || ""),
    summary: String(value.summary || ""),
    content: String(value.content || ""),
    publishedAt: String(value.publishedAt || "")
  });

  const fetchPosts = async () => {
    const response = await fetch(isEnglish ? "./posts-en.json" : "./posts.json", { cache: "no-store" });
    if (!response.ok) throw new Error(isEnglish ? "Articles are temporarily unavailable." : "文章文件暂时无法读取。");
    const data = await response.json();
    if (data.version !== 1 || !Array.isArray(data.posts)) throw new Error(isEnglish ? "Invalid article data." : "文章文件格式不正确。");
    return data.posts.map(normalize);
  };

  const sortedPosts = (items) => [...items].sort((a, b) => b.publishedAt.localeCompare(a.publishedAt));
  const articleHash = (id) => `#article/${encodeURIComponent(id)}`;

  const dateLabel = (value) => {
    if (!value) return "";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "";
    return new Intl.DateTimeFormat(isEnglish ? "en-US" : "zh-CN", {
      year: "numeric",
      month: "short",
      day: "numeric",
      timeZone: /^\d{4}-\d{2}-\d{2}$/.test(value) ? "UTC" : undefined
    }).format(date);
  };

  if (latestList) {
    const showLatestStatus = (message) => {
      latestList.replaceChildren(make("li", "latest-post-status", message));
    };

    fetchPosts()
      .then((items) => {
        if (!items.length) {
          showLatestStatus(isEnglish ? "No articles yet." : "还没有文章。");
          return;
        }

        const articlePage = isEnglish ? "./posts-en.html" : "./posts.html";
        const entries = sortedPosts(items).slice(0, 3).map((post) => {
          const entry = make("li");
          const link = make("a", "latest-post-link");
          link.href = articlePage + articleHash(post.id);
          link.append(make("span", "latest-post-title", post.title));

          const date = dateLabel(post.publishedAt);
          if (date) {
            const time = make("time", "latest-post-date", date);
            time.dateTime = post.publishedAt;
            link.append(time);
          }

          entry.append(link);
          return entry;
        });
        latestList.replaceChildren(...entries);
      })
      .catch(() => {
        showLatestStatus(isEnglish ? "Articles could not be loaded." : "暂时无法读取文章。");
      });
  }

  if (!grid || !postControls || !searchInput || !filterBar || !articleView || !feedback) return;

  const renderFilters = () => {
    const categories = [...new Set(posts.map((post) => post.category).filter(Boolean))];
    const categoryKey = JSON.stringify(categories);
    if (categories.length < 2) {
      filterBar.hidden = true;
      selectedCategory = allCategory;
      if (filterBar.dataset.categories !== categoryKey) {
        filterBar.replaceChildren();
        filterBar.dataset.categories = categoryKey;
      }
      return;
    }

    filterBar.hidden = false;
    if (filterBar.dataset.categories !== categoryKey) {
      filterBar.replaceChildren();
      [allCategory, ...categories].forEach((category) => {
        const button = make("button", "filter-button", category);
        button.type = "button";
        button.dataset.category = category;
        button.addEventListener("click", () => {
          selectedCategory = category;
          renderPosts();
        });
        filterBar.append(button);
      });
      filterBar.dataset.categories = categoryKey;
    }
    filterBar.querySelectorAll(".filter-button").forEach((button) => {
      button.setAttribute("aria-pressed", String(selectedCategory === button.dataset.category));
    });
  };

  const renderPosts = () => {
    renderFilters();
    grid.replaceChildren();
    postControls.hidden = posts.length === 0;
    const query = searchInput.value.trim().toLocaleLowerCase(isEnglish ? "en-US" : "zh-CN");
    const visiblePosts = sortedPosts(posts).filter((post) => {
      const matchesCategory = selectedCategory === allCategory || post.category === selectedCategory;
      const searchable = `${post.title} ${post.category} ${post.summary} ${post.content}`.toLocaleLowerCase(isEnglish ? "en-US" : "zh-CN");
      return matchesCategory && (!query || searchable.includes(query));
    });
    feedback.textContent = query ? (isEnglish ? `${visiblePosts.length} articles found` : `找到 ${visiblePosts.length} 篇文章`) : "";

    if (!posts.length) {
      const empty = make("div", "empty-state");
      empty.append(
        make("h3", "", isEnglish ? "No articles yet" : "这里还没有文章"),
        make("p", "", isEnglish ? "New posts will appear here." : "有新文章时会显示在这里。")
      );
      grid.append(empty);
      return;
    }

    if (!visiblePosts.length) {
      const empty = make("div", "empty-result-state");
      empty.append(make("p", "", isEnglish ? "No matching articles found." : "没有找到相关文章。"));
      const clearFilters = make("button", "text-link clear-filters", isEnglish ? "Clear search" : "清除搜索条件");
      clearFilters.type = "button";
      clearFilters.addEventListener("click", () => {
        selectedCategory = allCategory;
        searchInput.value = "";
        renderPosts();
        searchInput.focus();
      });
      empty.append(clearFilters);
      grid.append(empty);
      return;
    }

    visiblePosts.forEach((post) => {
      const card = make("a", "post-card");
      card.href = articleHash(post.id);
      card.setAttribute("aria-label", isEnglish ? `Read article: ${post.title}` : `阅读文章：${post.title}`);
      if (post.category) card.append(make("p", "post-category", post.category));

      card.append(make("h3", "post-title", post.title));

      const summary = post.summary || post.content.split(/\n\s*\n/)[0] || "";
      if (summary) card.append(make("p", "post-summary", summary));
      const date = dateLabel(post.publishedAt);
      if (date) {
        const time = make("time", "post-date", date);
        time.dateTime = post.publishedAt;
        card.append(time);
      }

      const readMore = make("span", "text-link post-more", isEnglish ? "Read article　↗" : "阅读全文　↗");
      const actions = make("div", "card-actions");
      actions.append(readMore);
      card.append(actions);
      grid.append(card);
    });
  };

  const showArticle = () => {
    const match = location.hash.match(/^#article\/(.+)$/);
    if (!match) {
      articleView.hidden = true;
      articleView.replaceChildren();
      grid.hidden = false;
      postControls.hidden = posts.length === 0;
      return;
    }

    let id;
    try {
      id = decodeURIComponent(match[1]);
    } catch {
      location.hash = "#posts";
      return;
    }

    const post = posts.find((item) => item.id === id);
    articleView.hidden = false;
    grid.hidden = true;
    postControls.hidden = true;
    articleView.replaceChildren();

    if (!post) {
      articleView.append(make("p", "empty-result", isEnglish ? "This article is unavailable." : "这篇文章不存在或已删除。"));
      return;
    }

    const back = make("a", "text-link article-back", isEnglish ? "←　All articles" : "←　所有文章");
    back.href = "#posts";
    articleView.append(back);

    const article = make("article", "reading-page");
    if (post.category) article.append(make("p", "post-category", post.category));
    const title = make("h1", "reading-title", post.title);
    title.tabIndex = -1;
    article.append(title);

    const date = dateLabel(post.publishedAt);
    if (date) {
      const time = make("time", "post-date", date);
      time.dateTime = post.publishedAt;
      article.append(time);
    }

    const content = make("div", "reading-content");
    post.content.split(/\n\s*\n/).filter((paragraph) => paragraph.trim()).forEach((paragraph) => {
      content.append(make("p", "", paragraph.trim()));
    });
    article.append(content);
    articleView.append(article);
  };

  window.addEventListener("hashchange", showArticle);
  searchInput.addEventListener("input", renderPosts);

  fetchPosts()
    .then((items) => {
      posts = items;
      feedback.textContent = "";
      renderPosts();
      showArticle();
    })
    .catch(() => {
      posts = [];
      postControls.hidden = true;
      feedback.textContent = "";
      grid.replaceChildren();
      const failure = make("div", "empty-state load-error");
      failure.append(
        make("h3", "", isEnglish ? "Articles could not be loaded" : "文章暂时无法读取"),
        make("p", "", isEnglish ? "Check your connection and refresh the page." : "检查网络后刷新页面试试。")
      );
      grid.append(failure);
    });
})();
