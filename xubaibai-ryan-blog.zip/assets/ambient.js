(() => {
  const canvas = document.querySelector(".ambient-canvas");
  const context = canvas?.getContext("2d", { alpha: true });
  if (!canvas || !context) return;

  const root = document.documentElement;
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  const cursor = { x: -1000, y: -1000, targetX: -1000, targetY: -1000, alpha: 0, targetAlpha: 0 };
  const particles = [];
  let width = 0;
  let height = 0;
  let pixelRatio = 1;
  let frame = 0;
  let previousFrameTime = 0;
  let lastParticleAt = 0;

  const colorsForTheme = () => root.dataset.theme === "light"
    ? ["79, 109, 132"]
    : ["170, 198, 222"];

  const resize = () => {
    pixelRatio = Math.min(window.devicePixelRatio || 1, 1.5);
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.round(width * pixelRatio);
    canvas.height = Math.round(height * pixelRatio);
    context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    requestDraw();
  };

  const spawnParticles = (x, y, now) => {
    if (now - lastParticleAt < 34) return;
    lastParticleAt = now;

    for (let index = 0; index < 2; index += 1) {
      particles.push({
        x: x + (Math.random() - 0.5) * 7,
        y: y + (Math.random() - 0.5) * 7,
        vx: (Math.random() - 0.5) * 0.75,
        vy: (Math.random() - 0.5) * 0.75,
        size: 2 + Math.random() * 2.5,
        life: 0.55 + Math.random() * 0.4,
        color: colorsForTheme()[Math.floor(Math.random() * 3)]
      });
    }

    if (particles.length > 32) particles.splice(0, particles.length - 32);
  };

  const draw = (now) => {
    frame = 0;
    if (document.hidden) return;

    context.clearRect(0, 0, width, height);
    const delta = previousFrameTime ? Math.min(now - previousFrameTime, 34) : 16.67;
    previousFrameTime = now;
    const easing = 1 - Math.exp(-delta / 75);
    cursor.x += (cursor.targetX - cursor.x) * easing;
    cursor.y += (cursor.targetY - cursor.y) * easing;
    cursor.alpha += (cursor.targetAlpha - cursor.alpha) * easing;

    root.style.setProperty("--spot-x", `${(cursor.x / Math.max(width, 1)) * 100}%`);
    root.style.setProperty("--spot-y", `${(cursor.y / Math.max(height, 1)) * 100}%`);
    root.style.setProperty("--spot-alpha", String(Math.min(cursor.alpha, 0.9)));

    const palette = colorsForTheme();
    const radius = 185;
    const spacing = 48;
    const startingAlpha = 0;

    for (let row = 0, y = 18; y < height; row += 1, y += spacing) {
      for (let column = 0, x = 18; x < width; column += 1, x += spacing) {
        const distance = Math.hypot(x - cursor.x, y - cursor.y);
        const influence = cursor.alpha * Math.max(0, 1 - distance / radius);
        const size = 1.5 + influence * 3.2;
        const alpha = startingAlpha + influence * 0.24;
        const color = palette[(column * 5 + row * 7) % palette.length];

        context.fillStyle = `rgba(${color}, ${alpha})`;
        context.fillRect(Math.round(x - size / 2), Math.round(y - size / 2), size, size);
      }
    }

    for (let index = particles.length - 1; index >= 0; index -= 1) {
      const particle = particles[index];
      particle.x += particle.vx * delta / 16.67;
      particle.y += particle.vy * delta / 16.67;
      particle.life -= delta / 550;
      if (particle.life <= 0) {
        particles.splice(index, 1);
        continue;
      }
      context.fillStyle = `rgba(${particle.color}, ${particle.life * cursor.alpha})`;
      context.fillRect(Math.round(particle.x), Math.round(particle.y), particle.size, particle.size);
    }

    const stillMoving = Math.abs(cursor.targetX - cursor.x) > 0.5
      || Math.abs(cursor.targetY - cursor.y) > 0.5
      || Math.abs(cursor.targetAlpha - cursor.alpha) > 0.008;
    if (stillMoving || particles.length > 0) requestDraw();
  };

  function requestDraw() {
    if (!frame && !reducedMotion.matches) frame = window.requestAnimationFrame(draw);
    else if (reducedMotion.matches) {
      cursor.x = cursor.targetX;
      cursor.y = cursor.targetY;
      cursor.alpha = cursor.targetAlpha;
      draw(performance.now());
    }
  }

  const handlePointerMove = (event) => {
    if (reducedMotion.matches || event.pointerType !== "mouse") return;
    cursor.targetX = event.clientX;
    cursor.targetY = event.clientY;
    cursor.targetAlpha = 1;
    const now = performance.now();
    spawnParticles(event.clientX, event.clientY, now);
    requestDraw();
  };

  const releasePointer = () => {
    cursor.targetAlpha = 0;
    requestDraw();
  };

  document.addEventListener("pointermove", handlePointerMove, { passive: true });
  document.documentElement.addEventListener("pointerleave", releasePointer);
  window.addEventListener("blur", releasePointer);
  window.addEventListener("resize", resize, { passive: true });
  window.addEventListener("site:themechange", requestDraw);
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      if (frame) window.cancelAnimationFrame(frame);
      frame = 0;
    } else {
      requestDraw();
    }
  });
  reducedMotion.addEventListener?.("change", requestDraw);
  resize();
})();
