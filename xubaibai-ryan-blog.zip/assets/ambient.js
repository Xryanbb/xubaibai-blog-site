(() => {
  const canvas = document.querySelector(".ambient-canvas");
  const context = canvas?.getContext("2d", { alpha: true });
  if (!canvas || !context) return;

  const root = document.documentElement;
  const showTerrain = !document.querySelector(".world-scene");
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  const cursor = { x: -1000, y: -1000, targetX: -1000, targetY: -1000, alpha: 0, targetAlpha: 0 };
  const particles = [];
  const tile = 24;
  let width = 0;
  let height = 0;
  let pixelRatio = 1;
  let frame = 0;
  let previousFrameTime = 0;
  let lastParticleAt = 0;
  let pointerIdleTimer = 0;

  const palette = () => root.dataset.theme === "light"
    ? { grass: "92, 133, 55", leaves: "121, 158, 76", dirt: "146, 119, 83", stone: "108, 126, 119", glint: "239, 248, 218" }
    : { grass: "122, 174, 81", leaves: "80, 129, 66", dirt: "112, 91, 70", stone: "110, 139, 145", glint: "201, 235, 154" };

  const seeded = (value) => {
    const sample = Math.sin(value * 127.1 + 311.7) * 43758.5453;
    return sample - Math.floor(sample);
  };

  const resize = () => {
    pixelRatio = Math.min(window.devicePixelRatio || 1, 1.5);
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.round(width * pixelRatio);
    canvas.height = Math.round(height * pixelRatio);
    context.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
    requestDraw();
  };

  const spawnBlocks = (x, y, now) => {
    if (now - lastParticleAt < 48) return;
    lastParticleAt = now;
    const colors = palette();
    const materials = [colors.grass, colors.dirt, colors.stone];

    for (let index = 0; index < 3; index += 1) {
      const size = 5 + Math.floor(Math.random() * 3) * 2;
      particles.push({
        x: x + (Math.random() - 0.5) * 16,
        y: y + (Math.random() - 0.5) * 16,
        vx: (Math.random() - 0.5) * 2.1,
        vy: -0.5 - Math.random() * 1.8,
        size,
        life: 0.75 + Math.random() * 0.25,
        color: materials[Math.floor(Math.random() * materials.length)]
      });
    }

    if (particles.length > 54) particles.splice(0, particles.length - 54);
  };

  const terrainHeightAt = (column) => {
    const a = Math.sin(column * 0.52) * 0.5;
    const b = Math.sin(column * 0.17 + 1.2) * 0.5;
    return 2 + Math.floor((a + b + 1) * 1.6);
  };

  const drawTerrain = (colors) => {
    const columns = Math.ceil(width / tile) + 1;
    const radius = 152;

    for (let column = 0; column < columns; column += 1) {
      const x = column * tile;
      const baseHeight = terrainHeightAt(column);
      const distance = Math.abs(x + tile / 2 - cursor.x);
      const influence = cursor.alpha * Math.max(0, 1 - distance / radius) * Math.max(0, 1 - Math.abs(cursor.y - (height - baseHeight * tile)) / 115);
      const lift = Math.round(influence * 1.5) * tile;

      for (let layer = 0; layer < baseHeight; layer += 1) {
        const y = height - (layer + 1) * tile - lift;
        const material = layer === baseHeight - 1 ? colors.grass : layer > baseHeight - 3 ? colors.dirt : colors.stone;
        const alpha = root.dataset.theme === "light" ? 0.105 : 0.16;
        context.fillStyle = `rgba(${material}, ${alpha})`;
        context.fillRect(x, y, tile - 1, tile - 1);
        context.fillStyle = `rgba(${colors.glint}, ${alpha * 0.32})`;
        context.fillRect(x, y, tile - 1, 2);
        context.fillStyle = `rgba(18, 28, 22, ${alpha * 0.22})`;
        context.fillRect(x, y + tile - 3, tile - 1, 2);
      }
    }

  };

  const drawFloatingPixels = (colors) => {
    const cols = Math.ceil(width / 64);
    const rows = Math.ceil(height / 64);
    for (let row = 1; row < rows; row += 1) {
      for (let column = 0; column < cols; column += 1) {
        if (seeded(row * 39 + column * 17) > 0.16) continue;
        const x = column * 64 + 13 + Math.floor(seeded(row * 19 + column * 31) * 18);
        const y = row * 64 + 12 + Math.floor(seeded(row * 11 + column * 23) * 17);
        const size = 3 + Math.floor(seeded(row * 7 + column * 43) * 3) * 2;
        context.fillStyle = `rgba(${colors.leaves}, ${root.dataset.theme === "light" ? 0.095 : 0.14})`;
        context.fillRect(x, y, size, size);
      }
    }
  };

  const drawCursor = (colors) => {
    if (cursor.alpha < 0.025) return;
    const size = 20;
    const grid = 8;
    const snappedX = Math.floor(cursor.x / grid) * grid;
    const snappedY = Math.floor(cursor.y / grid) * grid;
    const alpha = Math.min(cursor.alpha, 1);

    context.fillStyle = `rgba(${colors.grass}, ${alpha * 0.20})`;
    context.fillRect(snappedX, snappedY, size, size);
    context.strokeStyle = `rgba(${colors.glint}, ${alpha * 0.9})`;
    context.lineWidth = 2;
    context.strokeRect(snappedX + 1, snappedY + 1, size - 2, size - 2);

    // Four stepped corner marks keep the focus marker readable over both palettes.
    const mark = 5;
    context.fillStyle = `rgba(${colors.glint}, ${alpha})`;
    context.fillRect(snappedX - 2, snappedY - 2, mark, 2);
    context.fillRect(snappedX - 2, snappedY - 2, 2, mark);
    context.fillRect(snappedX + size - 3, snappedY - 2, mark, 2);
    context.fillRect(snappedX + size, snappedY - 2, 2, mark);
    context.fillRect(snappedX - 2, snappedY + size, mark, 2);
    context.fillRect(snappedX - 2, snappedY + size - 3, 2, mark);
    context.fillRect(snappedX + size - 3, snappedY + size, mark, 2);
    context.fillRect(snappedX + size, snappedY + size - 3, 2, mark);
  };

  const draw = (now) => {
    frame = 0;
    if (document.hidden) return;

    context.clearRect(0, 0, width, height);
    const delta = previousFrameTime ? Math.min(now - previousFrameTime, 34) : 16.67;
    previousFrameTime = now;
    const easing = reducedMotion.matches ? 1 : 1 - Math.exp(-delta / 75);
    cursor.x += (cursor.targetX - cursor.x) * easing;
    cursor.y += (cursor.targetY - cursor.y) * easing;
    cursor.alpha += (cursor.targetAlpha - cursor.alpha) * easing;

    const colors = palette();
    if (showTerrain) drawTerrain(colors);
    drawFloatingPixels(colors);
    drawCursor(colors);

    for (let index = particles.length - 1; index >= 0; index -= 1) {
      const block = particles[index];
      if (!reducedMotion.matches) {
        block.x += block.vx * delta / 16.67;
        block.y += block.vy * delta / 16.67;
        block.vy += 0.06 * delta / 16.67;
        block.life -= delta / 720;
      }
      if (block.life <= 0) {
        particles.splice(index, 1);
        continue;
      }
      context.fillStyle = `rgba(${block.color}, ${block.life * cursor.alpha})`;
      context.fillRect(Math.round(block.x / 2) * 2, Math.round(block.y / 2) * 2, block.size, block.size);
      context.fillStyle = `rgba(${colors.glint}, ${block.life * cursor.alpha * 0.45})`;
      context.fillRect(Math.round(block.x / 2) * 2, Math.round(block.y / 2) * 2, block.size, 2);
    }

    const stillMoving = Math.abs(cursor.targetX - cursor.x) > 0.5
      || Math.abs(cursor.targetY - cursor.y) > 0.5
      || Math.abs(cursor.targetAlpha - cursor.alpha) > 0.008;
    if (!reducedMotion.matches && (stillMoving || particles.length > 0)) requestDraw();
  };

  function requestDraw() {
    if (!frame && !reducedMotion.matches) frame = window.requestAnimationFrame(draw);
    else if (reducedMotion.matches) {
      cursor.x = cursor.targetX;
      cursor.y = cursor.targetY;
      cursor.alpha = cursor.targetAlpha;
      draw(performance.now());
    }
  }

  const handlePointerMove = (event) => {
    if (event.pointerType !== "mouse") return;
    cursor.targetX = event.clientX;
    cursor.targetY = event.clientY;
    cursor.targetAlpha = 1;
    window.clearTimeout(pointerIdleTimer);
    pointerIdleTimer = window.setTimeout(releasePointer, 900);
    const now = performance.now();
    if (!reducedMotion.matches) spawnBlocks(event.clientX, event.clientY, now);
    requestDraw();
  };

  const releasePointer = () => {
    window.clearTimeout(pointerIdleTimer);
    pointerIdleTimer = 0;
    cursor.targetAlpha = 0;
    requestDraw();
  };

  document.addEventListener("pointermove", handlePointerMove, { passive: true });
  document.documentElement.addEventListener("pointerleave", releasePointer);
  window.addEventListener("blur", releasePointer);
  window.addEventListener("resize", resize, { passive: true });
  window.addEventListener("site:themechange", requestDraw);
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      if (frame) window.cancelAnimationFrame(frame);
      frame = 0;
      previousFrameTime = 0;
    } else {
      requestDraw();
    }
  });
  reducedMotion.addEventListener?.("change", requestDraw);
  resize();
})();
