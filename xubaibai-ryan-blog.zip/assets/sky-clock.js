(() => {
  const root = document.documentElement;
  const themeColor = document.querySelector('meta[name="theme-color"]');
  const minutesPerDay = 24 * 60;
  const dawnStart = 4 * 60 + 45;
  const fullDay = 7 * 60 + 15;
  const duskStart = 15 * 60 + 45;
  const fullNight = 18 * 60 + 20;
  const moonrise = 17 * 60 + 10;
  const moonset = 5 * 60 + 55;

  // Each stop gives the upper sky, horizon and ground before the next blend.
  const night = [[31, 43, 61], [37, 55, 54], [27, 43, 35]];
  const day = [[202, 225, 232], [228, 237, 214], [219, 234, 217]];
  const skyStops = [
    { minute: 0, colors: night, stars: 1 },
    { minute: dawnStart, colors: night, stars: 1 },
    { minute: 5 * 60 + 30, colors: [[85, 74, 103], [138, 93, 94], [77, 76, 82]], stars: .55 },
    { minute: 6 * 60 + 20, colors: [[251, 207, 165], [247, 224, 191], [227, 219, 194]], stars: 0 },
    { minute: fullDay, colors: day, stars: 0 },
    { minute: duskStart, colors: day, stars: 0 },
    { minute: 16 * 60 + 20, colors: [[148, 159, 180], [228, 184, 151], [167, 158, 146]], stars: .05 },
    { minute: 16 * 60 + 55, colors: [[66, 56, 83], [145, 92, 81], [74, 65, 72]], stars: .42 },
    { minute: 17 * 60 + 40, colors: [[41, 44, 68], [82, 61, 76], [45, 45, 57]], stars: .82 },
    { minute: fullNight, colors: night, stars: 1 },
    { minute: minutesPerDay, colors: night, stars: 1 }
  ];
  const colorProperties = ["--clock-sky", "--clock-horizon", "--clock-ground"];
  const clamp01 = (value) => Math.min(1, Math.max(0, value));
  const smooth = (value) => value * value * (3 - 2 * value);
  const mix = (from, to, amount) => from + (to - from) * amount;
  const mixColor = (from, to, amount) => from.map((value, index) => Math.round(mix(value, to[index], amount)));
  const rgb = (channels) => `rgb(${channels.join(", ")})`;
  let minuteTimer;

  function setArc(name, minute, duration, fadeIn, fadeOut) {
    const progress = clamp01(minute / duration);
    const height = 1 - Math.sin(Math.PI * progress);
    const opacity = smooth(clamp01(Math.min(minute / fadeIn, (duration - minute) / fadeOut)));
    root.style.setProperty(`--${name}-x`, `${(12 + 76 * progress).toFixed(2)}%`);
    root.style.setProperty(`--${name}-drop`, Math.pow(height, 1.55).toFixed(3));
    root.style.setProperty(`--${name}-opacity`, opacity.toFixed(3));
  }

  function updateSky() {
    window.clearTimeout(minuteTimer);
    const now = new Date();
    const localMinute = now.getHours() * 60 + now.getMinutes() + now.getSeconds() / 60;
    let phase = "night";
    if (localMinute >= dawnStart && localMinute < fullDay) phase = "sunrise";
    if (localMinute >= fullDay && localMinute < duskStart) phase = "day";
    if (localMinute >= duskStart && localMinute < fullNight) phase = "sunset";

    const nextIndex = skyStops.findIndex((stop) => stop.minute > localMinute);
    const previous = skyStops[nextIndex - 1];
    const next = skyStops[nextIndex];
    const blend = smooth((localMinute - previous.minute) / (next.minute - previous.minute));
    const skyColors = previous.colors.map((color, index) => mixColor(color, next.colors[index], blend));
    skyColors.forEach((color, index) => root.style.setProperty(colorProperties[index], rgb(color)));
    root.style.setProperty("--stars-opacity", mix(previous.stars, next.stars, blend).toFixed(3));

    const center = mixColor(skyColors[0], skyColors[1], .68);
    const lightness = .213 * center[0] + .715 * center[1] + .072 * center[2];
    const theme = lightness >= 132 ? "light" : "dark";
    const changedTheme = root.dataset.theme !== theme;
    root.dataset.sky = phase;
    root.dataset.theme = theme;
    if (themeColor) themeColor.content = rgb(skyColors[2]);

    setArc("sun", localMinute - dawnStart, fullNight - dawnStart, 45, 85);
    const moonMinutes = (localMinute - moonrise + minutesPerDay) % minutesPerDay;
    setArc("moon", moonMinutes, minutesPerDay - moonrise + moonset, 80, 75);

    if (changedTheme) window.dispatchEvent(new Event("site:themechange"));
    if (!document.hidden) {
      const minuteMs = 60_000;
      minuteTimer = window.setTimeout(updateSky, minuteMs - (now.getTime() % minuteMs));
    }
  }

  window.addEventListener("pageshow", updateSky);
  window.addEventListener("focus", updateSky);
  document.addEventListener("visibilitychange", updateSky);
  updateSky();
})();
