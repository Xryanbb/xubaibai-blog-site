(() => {
  const root = document.documentElement;
  const themeColor = document.querySelector('meta[name="theme-color"]');
  const minutesPerDay = 24 * 60;
  const sunriseStart = 5 * 60 + 30;
  const dayStart = 7 * 60;
  const sunsetStart = 17 * 60 + 30;
  const nightStart = 19 * 60 + 30;
  const phases = {
    sunrise: { theme: "light", chrome: "#eee2d0" },
    day: { theme: "light", chrome: "#dbead9" },
    sunset: { theme: "dark", chrome: "#443b49" },
    night: { theme: "dark", chrome: "#1b2929" }
  };
  let minuteTimer;

  function updateSky() {
    window.clearTimeout(minuteTimer);
    const now = new Date();
    const localMinute = now.getHours() * 60 + now.getMinutes();
    let phase = "night";

    if (localMinute >= sunriseStart && localMinute < dayStart) phase = "sunrise";
    if (localMinute >= dayStart && localMinute < sunsetStart) phase = "day";
    if (localMinute >= sunsetStart && localMinute < nightStart) phase = "sunset";

    const previousPhase = root.dataset.sky;
    const { theme, chrome } = phases[phase];
    root.dataset.sky = phase;
    root.dataset.theme = theme;
    if (themeColor) themeColor.content = chrome;

    // The moon's path continues across midnight on the same arc.
    const nightMinutes = (localMinute - nightStart + minutesPerDay) % minutesPerDay;
    const nightDuration = minutesPerDay - nightStart + sunriseStart;
    const progress = phase === "night"
      ? nightMinutes / nightDuration
      : (localMinute - sunriseStart) / (nightStart - sunriseStart);
    root.style.setProperty("--sky-x", `${(12 + 76 * progress).toFixed(2)}%`);
    root.style.setProperty("--sky-drop", (1 - Math.sin(Math.PI * progress)).toFixed(3));

    if (phase !== previousPhase) window.dispatchEvent(new Event("site:themechange"));
    if (!document.hidden) {
      const minuteMs = 60_000;
      minuteTimer = window.setTimeout(updateSky, minuteMs - (now.getTime() % minuteMs));
    }
  }

  window.addEventListener("pageshow", updateSky);
  window.addEventListener("focus", updateSky);
  document.addEventListener("visibilitychange", updateSky);
  updateSky();
})();
