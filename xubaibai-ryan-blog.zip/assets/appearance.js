(() => {
  const root = document.documentElement;
  const themeKey = "xubaibai-blog-theme-v3";
  const nightPromptDateKey = "xubaibai-blog-night-prompt-date-v1";
  const isEnglish = root.lang.toLowerCase().startsWith("en");
  const themeLabel = (theme) => isEnglish
    ? (theme === "dark" ? "Switch to light mode" : "Switch to dark mode")
    : (theme === "dark" ? "切换浅色模式" : "切换深色模式");

  try {
    root.dataset.theme = localStorage.getItem(themeKey) === "dark" ? "dark" : "light";
  } catch {
    root.dataset.theme = "light";
  }

  const setTheme = (theme) => {
    root.dataset.theme = theme;
    try {
      localStorage.setItem(themeKey, theme);
    } catch {
      // Keep the selected theme for this page view if storage is unavailable.
    }

    const button = document.querySelector(".theme-toggle");
    button.setAttribute("aria-label", themeLabel(theme));
    document.querySelector('meta[name="theme-color"]').content = theme === "dark" ? "#1b2635" : "#f1f5f9";
    window.dispatchEvent(new Event("site:themechange"));
  };

  const localDateStamp = (date) => [
    date.getFullYear(),
    String(date.getMonth() + 1).padStart(2, "0"),
    String(date.getDate()).padStart(2, "0")
  ].join("-");

  const showNightModeSuggestion = () => {
    const now = new Date();
    if (now.getHours() < 18 || root.dataset.theme !== "light") return;

    try {
      if (localStorage.getItem(nightPromptDateKey) === localDateStamp(now)) return;
    } catch {
      // Show the prompt for this visit if browser storage is unavailable.
    }

    document.querySelector("#night-mode-suggestion").hidden = false;
  };

  const rememberNightModeSuggestion = () => {
    try {
      localStorage.setItem(nightPromptDateKey, localDateStamp(new Date()));
    } catch {
      // The prompt still closes for the current visit.
    }
  };

  const scheduleNightModeSuggestion = () => {
    const now = new Date();
    const nextEvening = new Date(now);
    nextEvening.setHours(18, 0, 0, 0);
    if (now.getHours() >= 18) nextEvening.setDate(nextEvening.getDate() + 1);

    window.setTimeout(() => {
      showNightModeSuggestion();
      scheduleNightModeSuggestion();
    }, Math.max(nextEvening.getTime() - now.getTime(), 1000));
  };

  document.addEventListener("DOMContentLoaded", () => {
    const button = document.querySelector(".theme-toggle");
    button.hidden = false;
    button.setAttribute("aria-label", themeLabel(root.dataset.theme));
    button.addEventListener("click", () => setTheme(root.dataset.theme === "dark" ? "light" : "dark"));

    const suggestion = document.querySelector("#night-mode-suggestion");
    document.querySelector("#use-night-mode").addEventListener("click", () => {
      rememberNightModeSuggestion();
      suggestion.hidden = true;
      setTheme("dark");
    });
    document.querySelector("#keep-day-mode").addEventListener("click", () => {
      rememberNightModeSuggestion();
      suggestion.hidden = true;
    });

    showNightModeSuggestion();
    scheduleNightModeSuggestion();
  }, { once: true });
})();
